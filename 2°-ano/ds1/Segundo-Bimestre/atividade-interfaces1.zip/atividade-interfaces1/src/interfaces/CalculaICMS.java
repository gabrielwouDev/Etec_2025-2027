package interfaces;

public class CalculaICMS implements IProcessarImpostos{

	@Override
	public double calcularImposto(double valor) {
		 double icms =  (valor*18)/100;
		 return icms;
		
	}
	
	
}
