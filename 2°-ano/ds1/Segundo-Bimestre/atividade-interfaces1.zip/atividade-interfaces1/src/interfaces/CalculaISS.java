package interfaces;

public class CalculaISS implements IProcessarImpostos{

	@Override
	public double calcularImposto(double valor) {
		double iss = (valor*5)/100;
		return iss;
	}

}
