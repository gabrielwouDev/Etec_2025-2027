package interfaces;
import javax.swing.JOptionPane;
public class App {
	
	public static void main(String[] args) {
		CalculaICMS icms = new CalculaICMS();
		CalculaISS iss = new CalculaISS();
		CalculaIPI ipi = new CalculaIPI();
		
		int opcao;
		double valor,totalImposto,saldoAtual;
		opcao = Integer.parseInt(JOptionPane.showInputDialog(null,"Escolha uma Opção: "+"\n"+"- 1 Calcular ICMS"+"\n"+"- 2 Calcular ISS"+"\n"+"- 3 Calcular IPI"));
		if(opcao == 1) {
			valor = Double.parseDouble(JOptionPane.showInputDialog(null,"Insira o valor: "));
			totalImposto = icms.calcularImposto(valor);
			saldoAtual = valor-totalImposto;
			JOptionPane.showMessageDialog(null, "Valor inicial: "+valor+"\n"+"Imposto ICMS: "+totalImposto+"\n"+"Valor atual: "+saldoAtual);
		}
		if(opcao == 2) {
			valor = Double.parseDouble(JOptionPane.showInputDialog(null,"Insira o valor: "));
			totalImposto = iss.calcularImposto(valor);
			saldoAtual = valor-totalImposto;
			JOptionPane.showMessageDialog(null, "Valor inicial: "+valor+"\n"+"Imposto ISS: "+totalImposto+"\n"+"Valor atual: "+saldoAtual);
		}
		if(opcao == 3) {
			valor = Double.parseDouble(JOptionPane.showInputDialog(null,"Insira o valor: "));
			totalImposto = ipi.calcularImposto(valor);
			saldoAtual = valor-totalImposto;
			JOptionPane.showMessageDialog(null, "Valor inicial: "+valor+"\n"+"Imposto IPI: "+totalImposto+"\n"+"Valor atual: "+saldoAtual);
		}

	}

}
