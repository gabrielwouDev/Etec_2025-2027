package interfaces;

public interface IProcessarImpostos {
	public double calcularImposto(double valor);

}
