package interfaces;

public class CalculaIPI implements IProcessarImpostos{

	@Override
	public double calcularImposto(double valor) {
		double ipi = (valor*10)/100;
		return ipi;
	}

}
