package view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.event.EventListenerList;

public class FormularioCliente extends JFrame{
		
	private JLabel lbNome,lbEmail,lbTel,lbCpf,lbCnpj,lbDtNasc,lbEstado,lbGenero;
	private JTextField txNome,txEmail,txTel,txCpf,txCnpj,txDtNasc;
	private JButton btExibir;
	private ButtonGroup grupoDeRadioGenero;
	private JRadioButton btMasc,btFem, btOutros;
	private JComboBox comboEstado;
	
	
	
	public FormularioCliente() {
		
		setTitle("Formulário");
		setSize(500,950);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		setLayout(null);
		getContentPane().setBackground(Color.LIGHT_GRAY);
		
		//nome
		lbNome = new JLabel();
		lbNome.setText("Nome:");
		lbNome.setBounds(70,80,100,30);
		add(lbNome);
		
		txNome = new JTextField();
		txNome.setBounds(130,80,250,30); 	
		add(txNome);
		
		//email
		lbEmail = new JLabel();
		lbEmail.setText("Email:");
		lbEmail.setBounds(70,120,100,30);
		add(lbEmail);
		
		txEmail = new JTextField();
		txEmail.setBounds(130,120,250,30);		
		add(txEmail);
		
		//telefone
		lbTel = new JLabel();
		lbTel.setText("Telefone:");
		lbTel.setBounds(70,160,100,30);
		add(lbTel);
		
		txTel = new JTextField();
		txTel.setBounds(130,160,250,30); 	
		add(txTel);
		
		//cpf
		lbCpf = new JLabel();
		lbCpf.setText("CPF:");
		lbCpf.setBounds(70,200,100,30);
		add(lbCpf);
		
		txCpf = new JTextField();
		txCpf.setBounds(130,200,250,30); 	
		add(txCpf);
		
		//cnpj
		lbCnpj = new JLabel();
		lbCnpj.setText("CNPJ:");
		lbCnpj.setBounds(70,240,100,30);
		add(lbCnpj);
		
		txCnpj = new JTextField();
		txCnpj.setBounds(130,240,250,30); 	
		add(txCnpj);
		
		//data de nascimento
		lbDtNasc = new JLabel();
		lbDtNasc.setText("<html> Data de<br>Nascimento:</html>");
		lbDtNasc.setBounds(40,280,150,30);
		add(lbDtNasc);
		
		txDtNasc = new JTextField();
		txDtNasc.setBounds(130,280,250,30); 	
		add(txDtNasc);
		
		
		lbEstado = new JLabel();
		lbEstado.setText("Estado:");
		lbEstado.setBounds(110,330,100,30);
		add(lbEstado);
		
		comboEstado = new JComboBox();

		comboEstado.addItem("SP");
		comboEstado.addItem("BA");
		comboEstado.addItem("MG");
		comboEstado.addItem("AM");
		
		comboEstado.setBounds(80,360,110,25);
		add(comboEstado);
		
		lbGenero = new JLabel();
		lbGenero.setText("Gênero:");
		lbGenero.setBounds(270,330,100,30);
		add(lbGenero);
		
		btMasc = new JRadioButton();
		btMasc.setBounds(210,360,100,25);
		btMasc.setText("Masculino");
		btMasc.setBackground(Color.LIGHT_GRAY);
		add(btMasc);		
		
		btFem = new JRadioButton();
		btFem.setBounds(310,360,100,25);
		btFem.setText("Feminino");
		btFem.setBackground(Color.LIGHT_GRAY);
		add(btFem);	
		
		grupoDeRadioGenero = new ButtonGroup(); 
		grupoDeRadioGenero.add(btMasc);
		grupoDeRadioGenero.add(btFem);
		
		
		btExibir = new JButton();
		btExibir.setText("Cadastrar");
		btExibir.setBounds(180,800,120,30);
		btExibir.setForeground(Color.WHITE);
		btExibir.setBackground(Color.BLACK); 
		
		btExibir.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				String nome = txNome.getText();
				String email = txEmail.getText();
				String telefone = txTel.getText();
				String cpf = txCpf.getText();
				String cnpj = txCnpj.getText();
				String dtNasc = txDtNasc.getText();
				String estado = (String) comboEstado.getSelectedItem();
				String genero;
				if(btMasc.isSelected()) {
					genero = "Masculino";
				}else {
					genero = "Feminino";
				}
				
				JOptionPane.showMessageDialog(null,
							"Nome: "+nome+"\n"+
							"Email: "+email+"\n"+
							"Telefone: "+telefone+"\n"+
							"CPF: "+cpf+"\n"+
							"CNPJ: "+cnpj+"\n"+
							"Data de Nascimento: "+dtNasc+"\n"+
							"Estado: "+estado+"\n"+
							"Genêro: "+genero
						);
				
				
				
				
			}
		});
		
						
		add(btExibir);		
		
		setVisible(true);//ÚLTIMA LINHA DO CONSTRUTOR
	}	
}
