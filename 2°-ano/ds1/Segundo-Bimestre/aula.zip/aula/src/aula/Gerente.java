package aula;

public class Gerente extends Funcionario{
	private String matricula;

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	public double aumentarSalario(double salario) {
		double total = (salario*20)/100; 
		return total;
	};
	
}
