package aula;

public class App {

	public static void main(String[] args) {
		Funcionario F1 = new Funcionario();
		Gerente G1 = new Gerente();
		
		

	}

}
