import heranca.Pessoa;

public class Cliente extends Pessoa{
	    private String endereco;

	    public String getEndereco() {
	        return endereco;
	    }

	    public void setEndereco(String endereco) {
	        this.endereco = endereco;
	    }

	@Override
	public void cadastrar(String nome,int idade,String cpf,String email) {
		setNome(nome);
		setIdade(idade);
		setCpf(cpf);
		setEmail(email);
	}

	


}
