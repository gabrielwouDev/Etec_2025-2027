import javax.swing.JOptionPane;
public class App {

	public static void main(String[] args) {
		Vendedor vendedor = new Vendedor();
		Cliente cliente = new Cliente();
		Carro carro = new Carro();
		Venda venda = new Venda();
		
		//instanciando o vendedor
		vendedor.cadastrar("Gabriel Penha", 28, "746.836.834-67","gabsP@gmail.com");
		vendedor.setMetaVendas(26.534);
		vendedor.setAssiduidade("87%");
		vendedor.setTotalVendido(13.800);
		
		//instanciando o cliente
		cliente.cadastrar("fl�vio", 35, "285.318.237-80", "flavioD@gmail.com");
		cliente.setEndereco("Rua do bico lascado, 134");
		
		//instanciando o carro
        carro.setMarca("Ford");
        carro.setModelo("Gt40");
        carro.setCor("Azul");
        carro.setAnoProducao("11/06/1965");
        carro.setPlaca("A XL 639");
        carro.setStatus("Carro com historico de batida, mas com estrutura renovada de fabrica e com modifica��es legais de rua");
		
        //criando a venda
        venda.setVendedor(vendedor.getNome());
        venda.setCliente(cliente.getNome());
        
        String data = JOptionPane.showInputDialog(null,"Insira a data da venda");
        venda.setDataVenda(data);
        
        double preco = Double.parseDouble(JOptionPane.showInputDialog(null,"Insira o pre�o")); 
        venda.setPreco(preco);
        
        int parcelas = Integer.parseInt(JOptionPane.showInputDialog(null,"Insira a quantidade de parcelas"));
        venda.setParcelas(parcelas);
        
        String comissao = JOptionPane.showInputDialog(null,"Insira a comissao do vendedor");
        venda.setComissaoVendedor(comissao);
        
        //exibindo a venda
        JOptionPane.showMessageDialog(null,"Modelo: "+carro.getModelo()+"\n"+
        			"Pre�o: "+venda.getPreco()+"\n"+
        			"Parcelas: "+venda.getParcelas()+"\n"+
        			"Vendedor: "+venda.getVendedor()+"\n"+
        			"Cliente: "+venda.getCliente()+"\n"+
        			"Comiss�o: "+venda.getComissaoVendedor()+"\n"+
        			"Data da venda: "+venda.getDataVenda()        		
        		);

	}

}
