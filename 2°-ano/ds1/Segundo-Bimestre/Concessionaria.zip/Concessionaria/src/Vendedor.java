import heranca.Pessoa;

public class Vendedor extends Pessoa{

    private double totalVendido;
    private double metaVendas;
    private String assiduidade;

    public double getTotalVendido() {
        return totalVendido;
    }

    public void setTotalVendido(double totalVendido) {
        this.totalVendido = totalVendido;
    }

    public double getMetaVendas() {
        return metaVendas;
    }

    public void setMetaVendas(double metaVendas) {
        this.metaVendas = metaVendas;
    }

    public String getAssiduidade() {
        return assiduidade;
    }

    public void setAssiduidade(String assiduidade) {
        this.assiduidade = assiduidade;
    }
    
    @Override
	public void cadastrar(String nome,int idade,String cpf,String email) {
		setNome(nome);
		setIdade(idade);
		setCpf(cpf);
		setEmail(email);
	}
}