import javax.swing.JOptionPane;
public class App {

	public static void main(String[] args) {
		Funcionario F1 = new Funcionario(0);
		Gerente G1 = new Gerente(0);
		ControleDeAumento controle = new ControleDeAumento();
		
		F1.setNome("josé da silva");
		F1.setCpf("278.271.687-53");
		F1.setSalario(2768);
		
		G1.setNome("Dom Pedro VI");
		G1.setCpf("145.657.345-35");
		G1.setSalario(10345);
		G1.setMatricula("145B23");
		
		JOptionPane.showMessageDialog(null,"Total de Aumento Gerente: "+G1.aumentarSalario(G1.getSalario()) +"\n"+"Total de Aumento Funcionário: " + F1.aumentarSalario(F1.getSalario())+"\n"+"Total dos aumentos: 		"+controle.getTotalDeAumento(F1.getSalario(),G1.getSalario())
		);
		
		

	}

}