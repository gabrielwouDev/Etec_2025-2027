

public class ControleDeAumento {
	private double totalF;
	private double totalG;
	
	public double getTotalDeAumento(double totalF,double totalG) {
		this.totalF = totalF;
		this.totalG = totalG;
		double totalAumento = totalF+totalG;
		return totalAumento;
	};

}
