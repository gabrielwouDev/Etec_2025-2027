
public class Gerente extends Funcionario{
	public Gerente(double salario) {
		super(salario);
	}

	private String matricula;

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	public double aumentarSalario(double salario) {
		double totalG = (salario*20)/100; 
		return totalG;
	};
	
}
