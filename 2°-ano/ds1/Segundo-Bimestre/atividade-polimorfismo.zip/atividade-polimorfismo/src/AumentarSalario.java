
public class AumentarSalario {
	    public double somaAumento(Funcionario funcionario,Gerente gerente) {
	        double totalAumento = funcionario.getSalario() * (10 / 100) + gerente.getSalario() * (20 / 100) ;
	        return totalAumento;
	    }
	}